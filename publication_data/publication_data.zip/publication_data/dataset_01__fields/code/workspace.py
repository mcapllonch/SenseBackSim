"""
This is a workspace module to allow the different modules sharing 
variables easily
Ideally, this module should not contain any code
"""